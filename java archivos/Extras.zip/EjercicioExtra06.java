/**
Leer la altura de N personas y determinar el promedio de estaturas que
se encuentran por debajo de 1.60 mts. y el promedio de estaturas en
general.
 * 
 */
package guia.pkg02;

import java.util.Scanner;

/**
 *
 * @author Leandro Arriola
 */
public class EjercicioExtra06 {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in).useDelimiter("\n");

        String letra;
        boolean continuar = true;
        double estatura, totalgeneral = 0, total160 = 0;
        int contadorgeneral = 0, contador160 = 0;

        while (continuar) {
            
            System.out.print("Introdusca una altura: ");
            estatura = read.nextDouble();
            
            totalgeneral = totalgeneral + estatura;
            contadorgeneral++;
            
            if (estatura < 1.60) {
                
                total160 = total160 + estatura;
                contador160++;
                
            }
            
            System.out.print("Introdusca 'S' si quiere seguir cargando mas estaturas de lo contrrio 'N': ");
            letra = read.next().toUpperCase();
            
            if (letra.equals("S")) {
                
            } else {
                
                continuar = false;
                
            }
            
        }
        
        System.out.println("El promedio general: " + (totalgeneral / contadorgeneral));
        System.out.println("El promeido de estaturas por debajo de 1,60: " + (total160 / contador160));
        
    }

}
