/**
Elaborar un algoritmo en el cuál se ingrese un número entre 1 y 10 y se
muestre su equivalente en romano.
 * 
 */
package guia.pkg02;

import java.util.Scanner;

/**
 *
 * @author Leandro Arriola
 */
public class EjercicioExtra04 {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in).useDelimiter("\n");
        
        int nro;

        System.out.print("Ingrese un numero entre 1 y 10: ");
        nro = read.nextInt();
        System.out.println(" ");
        
        if (nro >= 1 && nro <= 10) {
            
            switch(nro) {
                
                case 1:
                    
                    System.out.println("El " + nro + " es: I en Romano.");
                    break;
                case 2:
                    
                    System.out.println("El " + nro + " es: II en Romano.");
                    break;
                case 3:
                    
                    System.out.println("El " + nro + " es: III en Romano.");
                    break;
                case 4:
                    
                    System.out.println("El " + nro + " es: IV en Romano.");
                    break;
                case 5:
                    
                    System.out.println("El " + nro + " es: V en Romano.");
                    break;
                case 6:
                    
                    System.out.println("El " + nro + " es: VI en Romano.");
                    break;
                case 7:
                    
                    System.out.println("El " + nro + " es: VII en Romano.");
                    break;
                case 8:
                    
                    System.out.println("El " + nro + " es: VIII en Romano.");
                    break;
                case 9:
                    
                    System.out.println("El " + nro + " es: IX en Romano.");
                    break;
                case 10:
                    
                    System.out.println("El " + nro + " es: X en Romano.");
                    break;
            }
        } else {
            
            System.out.println("El numero no esta entre 1 y 10.");
            
        }
        
        System.out.println(" ");

    }

}
