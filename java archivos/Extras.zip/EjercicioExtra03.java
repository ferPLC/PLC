/**
Elaborar un algoritmo en el cuál se ingrese una letra y se detecte si se
trata de una vocal. Caso contrario mostrar un mensaje. Nota: investigar
la función equals() de la clase String.
 * 
 */
package guia.pkg02;

import java.util.Scanner;

/**
 *
 * @author Leandro Arriola
 */
public class EjercicioExtra03 {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in).useDelimiter("\n");
        
        char letra;
        
        System.out.println("Determinar si la letra introducida es vocal o no.");
        System.out.print("Ingrese una letra: ");
        letra = read.next().charAt(0);
        
        if (letra == 'a' || letra == 'e' || letra == 'i'|| letra == 'o' || letra == 'u' || letra == 'A' || letra == 'E' || letra == 'I' || letra == 'O' || letra == 'U') {
            
            System.out.println("La letra ingresada es una vocal");
            
        } else {
            
            System.out.println("La letra ingresada es una consonante");
            
        }

    }

}
