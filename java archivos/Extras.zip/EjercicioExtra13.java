/**
Crear un programa que dibuje una escalera de números, donde cada
línea de números comience en uno y termine en el número de la línea.
Solicitar la altura de la escalera al usuario al comenzar. Ejemplo: si se
ingresa el número 3ր
11
2
123
 * 
 */
package guia.pkg02;

import java.util.Scanner;

/**
 *
 * @author Leandro Arriola
 */
public class EjercicioExtra13 {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in).useDelimiter("\n");

        int n, i, j;
        
        System.out.println("Introduzca la altura de la escalera: ");
        n = read.nextInt();
        
        for (i = 1; i <= n; i++) {
            
            for (j = 1; j <= i; j++) {
                
                System.out.print(j);
                
            }
            
            System.out.println(" ");
            
        }
        
    }

}
