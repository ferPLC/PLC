/**
Declarar cuatro variables de tipo entero A, B, C y D y asignarle un valor
diferente a cada una. A continuación, realizar las instrucciones
necesarias para que: B tome el valor de C, C tome el valor de A, A tome
el valor de D y D tome el valor de B. Mostrar los valores iniciales y los
valores finales de cada variable. Utilizar sólo una variable auxiliar.
 * 
 */
package guia.pkg02;

import java.util.Scanner;

/**
 *
 * @author Leandro Arriola
 */
public class EjercicioExtra02 {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in).useDelimiter("\n");
        
        int A = 1, B = 2, C = 3, D = 4, aux;
        System.out.println("Valores iniciales.");
        System.out.println("A = " + A);
        System.out.println("B = " + B);
        System.out.println("C = " + C);
        System.out.println("D = " + D);
        
        aux = B;
        B = C;
        C = A;
        A = D;
        D = aux;
        
        System.out.println(" ");
        System.out.println("Valores finale.");
        System.out.println("B TOMO EL VALOR DE C -> B = " + B);
        System.out.println("C TOMO EL VALOR DE A -> C = " + C);
        System.out.println("A TOMO EL VALOR DE D -> A = " + A);
        System.out.println("D TOMO EL VALOR DE B -> D = " + D);

    }

}
