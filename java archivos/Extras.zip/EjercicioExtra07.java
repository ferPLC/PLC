/**
Realice un programa que calcule y visualice el valor máximo, el valor
mínimo y el promedio de n números (n>0). El valor de n se solicitará al
principio del programa y los números serán introducidos por el usuario.
Realice dos versiones del programa, una usando el bucle “while” y otra
con el bucle “do - while”.
 * 
 */
package guia.pkg02;

import java.util.Scanner;

/**
 *
 * @author Leandro Arriola
 */
public class EjercicioExtra07 {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in).useDelimiter("\n");

        int n, mayor = 0, menor = 10000, suma = 0, cont = 0;
        String letra;
        boolean continuar = true;

        while (continuar == true) 
        {
            System.out.print("Ingrese un valos cualquiera.");
            n = read.nextInt();
            
            System.out.println(" ");
            
            if (n > mayor) {
                mayor = n;
            }
            
            if (n < menor) {
                menor = n;
            }

            if (n > 0) {
                suma = suma + n;
                cont++;
                
            } else {
            }
            
            System.out.print("Quiere continuar S/N: ");
            letra = read.next().toUpperCase();
            
            if (letra.equals("S")) {
                
                continuar = true;
                
            } else {
                
                continuar = false;
                
            }
            
        }

        System.out.println(
                "El numero mayor ingresado fue: " + mayor);
        System.out.println(
                "El numero menor ingresado fue: " + menor);
        System.out.println(
                "El promedio de numeros mayores a 0 es: " + (suma / cont));
        
    }

}
