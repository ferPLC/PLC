/**
Se dispone de un conjunto de N familias, cada una de las cuales tiene
una M cantidad de hijos. Escriba un programa que pida la cantidad de
familias y para cada familia la cantidad de hijos para averiguar la media
de edad de los hijos de todas las familias.
 * 
 */
package guia.pkg02;

import java.util.Scanner;

/**
 *
 * @author Leandro Arriola
 */
public class EjercicioExtra14 {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in).useDelimiter("\n");
        
        int N, i, j, M, suma = 0, edad, cont = 0, contf = 0;

        System.out.print("Ingrese la cantidad de familias: ");
        N = read.nextInt();
        
        do {
            
            contf++;
            
            for (i = 0; i < N; i++) {
                
                System.out.println("Ingrese la cantidad de hijos de la familia: " + (i + 1));
                M = read.nextInt();
                
                for (j = 0; j < M; j++) {
                    
                    System.out.println("Ingresar la edad del hijo " + (j + 1));
                    edad = read.nextInt();
                    suma = suma + edad;
                    cont++;
                    
                }
                
            }
            
        } while (contf == N);
        
        System.out.println("El promedio de edad de los hijos de la/las " + N + " familias es: " + (suma / cont));

    }

}
