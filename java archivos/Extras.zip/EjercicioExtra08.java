/**
Escriba un programa que lea números enteros. Si el número es múltiplo
de cinco debe detener la lectura y mostrar la cantidad de números
leídos, la cantidad de números pares y la cantidad de números impares.
Al igual que en el ejercicio anterior los números negativos no deben
sumarse. Nota: recordar el uso de la sentencia break
 * 
 */
package guia.pkg02;

import java.util.Scanner;

/**
 *
 * @author Leandro Arriola
 */
public class EjercicioExtra08 {

    public static void main(String[] args) {

        Scanner read = new Scanner(System.in).useDelimiter("\n");

        int nro, resto, cont = 0, contpar = 0, contimpar = 0;
        boolean multi = false;

        do {
            
            System.out.print("Ingrese cualquier numero: ");
            nro = read.nextInt();
            
            if (nro > 0) {
                
                cont++;
                resto = nro % 5;
                
                if (resto == 0) {
                    
                    System.out.println("Se encontro un numero multiplo de 5.");
                    multi = true;
                    break;
                    
                }
                
                if (nro % 2 == 0) {
                    
                    contpar++;
                    
                } else {
                    
                    contimpar++;
                    
                }
                {
                }
                
            }
            
        } while (multi == false);
        
        System.out.println("");
        System.out.println("La cantidad de numeros ingresados fue: " + cont);
        System.out.println("La cantidad de numeros pares es: " + contpar);
        System.out.println("La cantidad de numeros impares es: " + contimpar);
        
    }

}
